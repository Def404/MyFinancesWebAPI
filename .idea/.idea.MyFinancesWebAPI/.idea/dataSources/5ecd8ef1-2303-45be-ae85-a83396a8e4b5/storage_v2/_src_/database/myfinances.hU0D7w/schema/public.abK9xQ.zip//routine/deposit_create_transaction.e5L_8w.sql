create function deposit_create_transaction() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO transactions(amount, transaction_date, login, deposit_id ,transaction_type_id) VALUES (NEW.amount, date(now()), NEW.login, NEW.deposit_id, 7);
    RETURN NEW;
END;
$$;

alter function deposit_create_transaction() owner to adef;

