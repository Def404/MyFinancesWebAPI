create function get_monthly_interest(amount money, interest_rate smallint) returns money
    language plpgsql
as
$$
DECLARE
    monthly_interest money;
BEGIN
    monthly_interest := amount * (interest_rate::decimal / (100 * 12));
    RETURN monthly_interest;
END;
$$;

alter function get_monthly_interest(money, smallint) owner to adef;

