create function delete_interest_rates() returns trigger
    language plpgsql
as
$$
BEGIN
    EXECUTE format('DELETE FROM interest_rates WHERE credit_card_num = %s', OLD.credit_card_id);
    RETURN NULL;
END;
$$;

alter function delete_interest_rates() owner to adef;

