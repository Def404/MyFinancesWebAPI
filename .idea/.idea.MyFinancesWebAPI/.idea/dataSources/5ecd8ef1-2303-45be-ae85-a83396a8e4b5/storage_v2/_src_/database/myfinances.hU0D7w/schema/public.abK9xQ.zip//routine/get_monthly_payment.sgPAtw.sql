create function get_monthly_payment(amount money, interest_rate smallint, start_date date, period integer) returns money
    language plpgsql
as
$$
DECLARE
    monthly_payment money;
    between_month int;
    passed_period interval;
    monthly_interest_rate decimal;
BEGIN
    passed_period:=(SELECT age(start_date));
    between_month:= (SELECT period - (SELECT EXTRACT(YEAR FROM passed_period) * 12 + EXTRACT(MONTH FROM passed_period)));
    monthly_interest_rate:= interest_rate::decimal/(100*12);
    monthly_payment := amount * (monthly_interest_rate / (1 - (1 + monthly_interest_rate)^(-between_month)));
    return monthly_payment;
END;
$$;

alter function get_monthly_payment(money, smallint, date, integer) owner to adef;

