create view transaction_for_loan(transaction_type_id, name, class) as
SELECT transaction_types.transaction_type_id,
       transaction_types.name,
       transaction_types.class
FROM transaction_types
WHERE transaction_types.transaction_type_id = 9;

alter table transaction_for_loan
    owner to adef;

grant select on transaction_for_loan to regular_user;

