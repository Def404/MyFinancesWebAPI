create function loan_create_transaction() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO transactions(amount, transaction_date, login, loan_id ,transaction_type_id) VALUES (NEW.amount, date(now()), NEW.login, NEW.loan_id, 7);
    RETURN NEW;
END;
$$;

alter function loan_create_transaction() owner to adef;

