create function add_subscription_transaction() returns trigger
    language plpgsql
as
$$
    DECLARE
        descr varchar(150);
BEGIN
    IF NEW.bank_account_id IS NOT NULL THEN
        descr := 'Подписка ' || NEW.name;
        INSERT INTO transactions(amount, transaction_date, description, login, bank_account_id, transaction_type_id)
        VALUES (NEW.price, NEW.purchase_date, descr, NEW.login, NEW.bank_account_id, 5);
    END IF;
    RETURN NEW;
END;
$$;

alter function add_subscription_transaction() owner to adef;

