create function bank_account_create_transaction() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO transactions(amount, transaction_date, login, bank_account_id, transaction_type_id) VALUES (NEW.balance, date(now()), NEW.login, NEW.bank_account_id, 7);
    RETURN NEW;
END;
$$;

alter function bank_account_create_transaction() owner to adef;

