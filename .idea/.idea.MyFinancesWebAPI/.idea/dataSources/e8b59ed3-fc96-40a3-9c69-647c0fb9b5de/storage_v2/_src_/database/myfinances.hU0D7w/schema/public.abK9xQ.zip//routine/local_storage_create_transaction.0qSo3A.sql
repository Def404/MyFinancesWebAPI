create function local_storage_create_transaction() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO transactions(amount, transaction_date, login, local_storage_id, transaction_type_id)
        VALUES (NEW.balance, date(now()), NEW.login, NEW.local_storage_id, 7);
        RETURN NEW;
END;
$$;

alter function local_storage_create_transaction() owner to adef;

