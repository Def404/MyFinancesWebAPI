create procedure create_user(IN c_login character varying, IN c_first_name character varying, IN c_last_name character varying, IN c_email character varying, IN c_birth_date date, IN c_password text)
    language plpgsql
as
$$
BEGIN
    IF (SELECT  count(*) FROM pg_roles WHERE rolname = c_login)
        THEN RAISE EXCEPTION 'Такой пользователь уже сущесвует';
    ELSE
        INSERT INTO
            users(login,
                  first_name,
                  last_name,
                  password,
                  email,
                  birth_date,
                  registration_date)
        VALUES (c_login,
                c_first_name,
                c_last_name,
                crypt(c_password, gen_salt('md5')),
                c_email,
                c_birth_date,
                date(now()));

        EXECUTE format('CREATE ROLE %s WITH LOGIN PASSWORD %L;', c_login, c_password);
        EXECUTE format('GRANT regular_user TO %s;',  c_login);
        COMMIT;
    END IF;
END
$$;

alter procedure create_user(varchar, varchar, varchar, varchar, date, text) owner to adef;

