create view transaction_for_local_storage(transaction_type_id, name, class) as
SELECT transaction_types.transaction_type_id,
       transaction_types.name,
       transaction_types.class
FROM transaction_types
WHERE transaction_types.transaction_type_id = ANY (ARRAY [1, 2, 3, 4, 8]);

alter table transaction_for_local_storage
    owner to adef;

grant select on transaction_for_local_storage to regular_user;

