create procedure update_user_password(IN u_login character varying, IN u_password text)
    language plpgsql
as
$$
BEGIN
    IF (SELECT count(*) FROM users WHERE login = u_login AND password = crypt(u_password, password))
    THEN
        RAISE EXCEPTION 'Новый пароль совпадает со старым';
    ELSE
        UPDATE users SET password = crypt(u_password, gen_salt('md5')) WHERE login = u_login;
        EXECUTE format('ALTER ROLE %s WITH PASSWORD %L', u_login, u_password);
        COMMIT;
    END IF;
END;
$$;

alter procedure update_user_password(varchar, text) owner to adef;

