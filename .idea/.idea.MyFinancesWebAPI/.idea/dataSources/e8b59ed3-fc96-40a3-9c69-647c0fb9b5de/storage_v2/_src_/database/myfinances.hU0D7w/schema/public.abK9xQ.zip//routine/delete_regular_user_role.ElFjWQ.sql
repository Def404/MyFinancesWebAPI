create function delete_regular_user_role() returns trigger
    language plpgsql
as
$$
BEGIN
    EXECUTE format('DROP ROLE %R;', OLD.login);
    RETURN NULL;
END;
$$;

alter function delete_regular_user_role() owner to adef;

