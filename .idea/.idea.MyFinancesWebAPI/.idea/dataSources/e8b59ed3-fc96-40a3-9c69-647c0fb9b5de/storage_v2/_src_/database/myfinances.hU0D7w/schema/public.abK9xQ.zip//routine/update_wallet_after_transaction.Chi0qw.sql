create function update_wallet_after_transaction() returns trigger
    language plpgsql
as
$$
DECLARE
    my_class char(1);

BEGIN
    IF NEW.transaction_type_id <> 7 THEN
        my_class := (SELECT class FROM transaction_types WHERE transaction_type_id = NEW.transaction_type_id);
        IF NEW.bank_account_id IS NOT NULL THEN
            IF my_class = '+' THEN
                UPDATE bank_accounts
                SET balance = balance + NEW.amount
                WHERE bank_account_id = NEW.bank_account_id;
            ELSE
                UPDATE bank_accounts
                SET balance = balance - NEW.amount
                WHERE bank_account_id = NEW.bank_account_id;
            END IF;
        END IF;
        IF NEW.deposit_id IS NOT NULL THEN
            IF my_class = '+' THEN
                UPDATE deposits
                SET amount = amount + NEW.amount
                WHERE deposit_id = NEW.deposit_id;
            ELSE
                UPDATE deposits
                SET amount = amount - NEW.amount
                WHERE deposit_id = NEW.deposit_id;
            END IF;
        END IF;
        IF NEW.credit_card_id IS NOT NULL THEN
            IF my_class = '+' THEN
                UPDATE credit_cards
                SET credit_limit = credit_limit + NEW.amount
                WHERE credit_card_id = NEW.credit_card_id;
            ELSE
                UPDATE credit_cards
                SET credit_limit = credit_limit - NEW.amount
                WHERE credit_card_id = NEW.credit_card_id;
            END IF;
        END IF;
        IF NEW.loan_id IS NOT NULL THEN
            IF my_class = '-' THEN
                IF (SELECT count(*)
                    FROM transactions t
                    WHERE t.loan_id = NEW.loan_id
                      AND transaction_type_id <> 7
                      AND EXTRACT(YEAR FROM transaction_date) = EXTRACT(YEAR FROM current_date)
                      AND EXTRACT(MONTH FROM transaction_date) = EXTRACT(MONTH FROM current_date)) <> 0 THEN
                    RAISE EXCEPTION 'В этом месяце уже был платеж';
                ELSE
                    UPDATE loans l
                    SET amount = amount - (get_monthly_payment(l.amount, l.interest_rate, l.start_date, l.credit_period) - get_monthly_interest(l.amount, l.interest_rate))
                    WHERE loan_id = NEW.loan_id;
                END IF;
            END IF;
        END IF;
        IF NEW.local_storage_id IS NOT NULL THEN
            IF my_class = '+' THEN
                UPDATE local_storage
                SET balance = balance + NEW.amount
                WHERE local_storage_id = NEW.local_storage_id;
            ELSE
                UPDATE local_storage
                SET balance = balance - NEW.amount
                WHERE local_storage_id = NEW.local_storage_id;
            END IF;
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function update_wallet_after_transaction() owner to adef;

