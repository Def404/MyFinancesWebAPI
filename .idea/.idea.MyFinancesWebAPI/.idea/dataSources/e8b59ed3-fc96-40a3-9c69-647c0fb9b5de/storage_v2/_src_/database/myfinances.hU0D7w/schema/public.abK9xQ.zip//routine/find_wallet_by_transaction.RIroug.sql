create function find_wallet_by_transaction(id_transaction bigint)
    returns TABLE(transaction_id_t bigint, wallet_name character varying, currency_sign character)
    language plpgsql
as
$$
DECLARE
    wallet_name varchar;
    currency_sign char;
BEGIN
    IF (SELECT bank_account_id
        FROM transactions
        WHERE transaction_id = id_transaction) IS NOT NULL THEN
        wallet_name := (SELECT ba.name
                        FROM transactions
                                 LEFT JOIN bank_accounts ba on ba.bank_account_id = transactions.bank_account_id
                        WHERE transaction_id = id_transaction);
        currency_sign := (SELECT c.sign
                          FROM transactions
                                   LEFT JOIN bank_accounts b on b.bank_account_id = transactions.bank_account_id
                                   JOIN currencies c on c.currency_id = b.currency_id
                          WHERE transaction_id = id_transaction);
        RETURN QUERY SELECT id_transaction, wallet_name, currency_sign;
    ELSIF (SELECT deposit_id
           FROM transactions
           WHERE transaction_id = id_transaction) IS NOT NULL THEN
        wallet_name := (SELECT d.name
                        FROM transactions
                                 LEFT JOIN deposits d on d.deposit_id = transactions.deposit_id
                        WHERE transaction_id = id_transaction);
        currency_sign := (SELECT c.sign
                          FROM transactions
                                   LEFT JOIN deposits d on d.deposit_id = transactions.deposit_id
                                   JOIN currencies c on c.currency_id = d.currency_id
                          WHERE transaction_id = id_transaction);

        RETURN QUERY SELECT id_transaction, wallet_name, currency_sign;
    ELSIF (SELECT credit_card_id
           FROM transactions
           WHERE transaction_id = id_transaction) IS NOT NULL THEN
        wallet_name := (SELECT cc.name
                        FROM transactions
                                 LEFT JOIN credit_cards cc on cc.credit_card_id = transactions.credit_card_id
                        WHERE transaction_id = id_transaction);
        currency_sign := (SELECT c.sign
                          FROM transactions
                                   LEFT JOIN credit_cards cc on cc.credit_card_id = transactions.credit_card_id
                                   JOIN currencies c on c.currency_id = cc.currency_id
                          WHERE transaction_id = id_transaction);

        RETURN QUERY SELECT id_transaction, wallet_name, currency_sign;
    ELSIF (SELECT loan_id
           FROM transactions
           WHERE transaction_id = id_transaction) IS NOT NULL THEN
        wallet_name := (SELECT l.name
                        FROM transactions
                                 LEFT JOIN loans l on transactions.loan_id = l.loan_id
                        WHERE transaction_id = id_transaction);
        currency_sign := (SELECT c.sign
                          FROM transactions
                                   LEFT JOIN loans l on transactions.loan_id = l.loan_id
                                   JOIN currencies c on c.currency_id = l.currency_id
                          WHERE transaction_id = id_transaction);

        RETURN QUERY SELECT id_transaction, wallet_name, currency_sign;
    ELSIF (SELECT local_storage_id
           FROM transactions
           WHERE transaction_id = id_transaction) IS NOT NULL THEN
        wallet_name := (SELECT ls.name
                        FROM transactions
                                 LEFT JOIN local_storage ls on ls.local_storage_id = transactions.local_storage_id
                        WHERE transaction_id = id_transaction);
        currency_sign := (SELECT c.sign
                          FROM transactions
                                   LEFT JOIN local_storage ls on ls.local_storage_id = transactions.local_storage_id
                                   JOIN currencies c on c.currency_id = ls.currency_id
                          WHERE transaction_id = id_transaction);

        RETURN QUERY SELECT id_transaction, wallet_name, currency_sign;
    END IF;
END;
$$;

alter function find_wallet_by_transaction(bigint) owner to adef;

